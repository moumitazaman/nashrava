Message from : {{ $name }}
<p> Name: {{ $name }}</p>
<p>E-mail: {{ $email }}</p>
<p>Phone: {{ $phone }}</p>
<p>Order no: {{ $order_no }}</p>
<p>Reason of Exchange: {{ $messageBody }}</p>
<p>Exchange product: {{ $exstyle }}</p>
<p>Exchange size: {{ $exsize }}</p>
<p>Requested product: {{ $style }}</p>
<p>Requested size: {{ $size }}</p>
<p>Message: {{ $messageReq }}</p>