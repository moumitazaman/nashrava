Message from : {{ $name }}
<p> Name: {{ $name }}</p>
<p>E-mail: {{ $email }}</p>
<p>Message: {{ $messageBody }}</p>