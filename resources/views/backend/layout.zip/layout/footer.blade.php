 <footer class="main-footer" style="background-color: #505F6D;color: white">
    <strong>Developed by ICICLE CORPORATION; 2021 <a style="color:white" href="https://iciclecorporation.com/">ICICLE CORPORATION</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b>1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

